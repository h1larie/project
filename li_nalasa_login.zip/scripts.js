var Username;
function username(){
    Username = document.getElementById("username").value;
}

var Password;
function password(){
    Password = document.getElementById("").value;
}

function submit(){
	if(Username == null){
		document.getElementById("display1").innerHTML = ("Please enter your username");
	}
	if(Password == null){
		document.getElementById("display2").innerHTML = ("Please enter your password");
	}
	if(Password == null || Username == null){
		console.log("Login Error");
	}
}